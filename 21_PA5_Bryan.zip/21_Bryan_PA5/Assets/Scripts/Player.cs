﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float speed = 40f;
    Rigidbody PlayerRigidbody;

    public int coinsCollected = 0;

    public Text txt_coins;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if (coinsCollected == 4)
        {
            SceneManager.LoadScene(1);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("Coins"))
        {
            Destroy(collision.gameObject);
            coinsCollected += 1;
            txt_coins.text = "Coins: " + coinsCollected;
        }
        if(collision.gameObject.CompareTag("Walls"))
        {
            Destroy(gameObject);
            SceneManager.LoadScene(2);
        }
    }
}
